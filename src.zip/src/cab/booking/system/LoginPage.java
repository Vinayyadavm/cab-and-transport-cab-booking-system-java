package cab.booking.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LoginPage extends JFrame {

    public LoginPage() {
        // Set up the JFrame
        super("Login Page");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300, 250);
        setLocationRelativeTo(null);

        // Create the UI components
        JLabel label = new JLabel("Login Form");
        JLabel emailLabel = new JLabel("Email:");
        JLabel passwordLabel = new JLabel("Password:");
        JTextField emailTextField = new JTextField();
        JPasswordField passwordField = new JPasswordField();
        JButton loginButton = new JButton("Login");
        JButton registerButton = new JButton("Register");

        // Add the components to the JFrame
        Container contentPane = getContentPane();
        contentPane.setLayout(new GridLayout(4, 2));
        contentPane.add(emailLabel);
        contentPane.add(emailTextField);
        contentPane.add(passwordLabel);
        contentPane.add(passwordField);
        contentPane.add(new JLabel(""));
        contentPane.add(loginButton);
        contentPane.add(new JLabel(""));
        contentPane.add(registerButton);

        // Add event listener to the login button
        loginButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Validate email
                String email = emailTextField.getText();
                if (!isValidEmail(email)) {
                    JOptionPane.showMessageDialog(LoginPage.this, "Invalid email address", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                // TODO: Implement login logic
                // Once login is successful, redirect to the appropriate page
                // For example, if the user is an admin, redirect to the admin section page
                // Otherwise, redirect to the user dashboard page
                AdminSection AdminSection  = new AdminSection ();
                AdminSection .setVisible(true);
                dispose();
            }
        });

        // Add event listener to the register button
        registerButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Open the registration page
                AdminRegistration adminRegistrationPage = new AdminRegistration();
                adminRegistrationPage.setVisible(true);
                dispose();
            }
        });
    }
    
    // Email validation function
    private boolean isValidEmail(String email) {
        String regex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }

    public static void main(String[] args) {
        // Create and show the login page
        LoginPage loginPage = new LoginPage();
        loginPage.setVisible(true);
    }
}
