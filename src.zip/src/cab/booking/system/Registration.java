/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cab.booking.system;


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class Registration extends JFrame implements ActionListener{

    private JPanel panel;
    private JTextField nameField, usernameField;
    private JPasswordField passwordField;
    private JButton registerButton, backButton;

    public Registration() {
        // Set up the JFrame
        super("Registration");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);
        setLocationRelativeTo(null);

        // Create the UI components
        JLabel nameLabel = new JLabel("Name:");
        nameField = new JTextField(20);

        JLabel usernameLabel = new JLabel("Username:");
        usernameField = new JTextField(20);

        JLabel passwordLabel = new JLabel("Password:");
        passwordField = new JPasswordField(20);

        registerButton = new JButton("Register");
        registerButton.addActionListener(this);

        backButton = new JButton("Back");
        backButton.addActionListener(this);

        // Add the components to the JFrame
        panel = new JPanel(new GridLayout(4, 2));
        panel.add(nameLabel);
        panel.add(nameField);
        panel.add(usernameLabel);
        panel.add(usernameField);
        panel.add(passwordLabel);
        panel.add(passwordField);
        panel.add(registerButton);
        panel.add(backButton);

        Container contentPane = getContentPane();
        contentPane.add(panel, BorderLayout.CENTER);
    }

    public void actionPerformed(ActionEvent ae) {
        if(ae.getSource() == registerButton) {
            try {
                // Connect to the database
                Conn con = new Conn();

                // Get the user input from the text fields
                String name = nameField.getText();
                String username = usernameField.getText();
                String password = passwordField.getText();

                // Check if the username is already taken
                String query = "SELECT * FROM account WHERE username=?";
                PreparedStatement statement = con.c.prepareStatement(query);
                statement.setString(1, username);
                ResultSet resultSet = statement.executeQuery();

                if (resultSet.next()) {
                    JOptionPane.showMessageDialog(null, "Username is already taken.");
                } else {
                    // Insert the new user into the database
                    String insertQuery = "INSERT INTO account (name, username, password) VALUES (?, ?, ?)";
                    PreparedStatement insertStatement = con.c.prepareStatement(insertQuery);
                    insertStatement.setString(1, name);
                    insertStatement.setString(2, username);
                    insertStatement.setString(3, password);
                    insertStatement.executeUpdate();

                    JOptionPane.showMessageDialog(null, "Registration successful!");

                    // Open the login page
                    Login loginPage = new Login();
                    loginPage.setVisible(true);
                    dispose();
                }
            } catch(Exception e) {
                e.printStackTrace();
            }
        } else if(ae.getSource() == backButton) {
            // Open the index page
            IndexPage indexPage = new IndexPage();
            indexPage.setVisible(true);
            dispose();
        }
    }

    public static void main(String[] args) {
        // Create and show the registration page
        Registration registrationPage = new Registration();
        registrationPage.setVisible(true);
    }
}
