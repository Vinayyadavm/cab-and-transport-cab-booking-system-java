package cab.booking.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class IndexPage extends JFrame {
    
    public IndexPage() {
    // Set up the JFrame
    super("Index Page");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setSize(300, 200);
    setLocationRelativeTo(null);
    
    // Create the UI components
    JLabel label = new JLabel("Choose a login type:");
    JButton customerButton = new JButton("Customer Login");
    JButton adminButton = new JButton("Admin Login");
    
    // Add the components to the JFrame
    Container contentPane = getContentPane();
    contentPane.setLayout(new BorderLayout());
    contentPane.add(label, BorderLayout.NORTH);
    
    JPanel buttonPanel = new JPanel();
    buttonPanel.add(customerButton);
    buttonPanel.add(adminButton);
    contentPane.add(buttonPanel, BorderLayout.CENTER);
    
    // Add event listeners to the buttons
    customerButton.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            // Open the customer login page
            Login customerLoginPage = new Login ();
            customerLoginPage.setVisible(true);
            dispose();
        }
    });
    
    adminButton.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            // Open the admin login page
            LoginPage LoginPage = new  LoginPage();
             LoginPage.setVisible(true);
            dispose();
        }
    });
}

public static void main(String[] args) {
    // Create and show the index page
    IndexPage indexPage = new IndexPage();
    indexPage.setVisible(true);
}
}