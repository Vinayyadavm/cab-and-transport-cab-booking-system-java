package cab.booking.system;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileOutputStream;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import java.io.FileOutputStream;
import java.util.Date;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.awt.HeadlessException;
import java.io.FileNotFoundException;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;

public class CabInvoiceGenerator {

    public static void main(String[] args) {
        // Create a new instance of the CabInvoiceGenerator class and display the UI
        CabInvoiceGenerator cabInvoiceGenerator = new CabInvoiceGenerator();
        cabInvoiceGenerator.setVisible(true);
    }

CabInvoiceGenerator() {
        JFrame frame = new JFrame("Cab Invoice Generator");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Create the form panel
        JPanel formPanel = new JPanel();

        // Add the name field
        JLabel nameLabel = new JLabel("Name:");
        JTextField nameField = new JTextField(20);
        formPanel.add(nameLabel);
        formPanel.add(nameField);

        // Add the phone number field
        JLabel phoneLabel = new JLabel("Phone Number:");
        JTextField phoneField = new JTextField(20);
        formPanel.add(phoneLabel);
        formPanel.add(phoneField);

        // Add the credit card fields
        JLabel cardLabel = new JLabel("Credit Card Number:");
        JTextField cardField = new JTextField(20);
        formPanel.add(cardLabel);
        formPanel.add(cardField);

        JLabel expLabel = new JLabel("Expiration Date:");
        JTextField expField = new JTextField(10);
        formPanel.add(expLabel);
        formPanel.add(expField);

       JLabel cvvLabel = new JLabel("CVV:");
       JPasswordField cvvField = new JPasswordField(5);
       cvvField.setEchoChar('\u2022'); // Use a dot as the echo character
       formPanel.add(cvvLabel);
       formPanel.add(cvvField);



        // Add the generate button
        JButton generateButton = new JButton("Generate Invoice");
        generateButton.addActionListener((ActionEvent e) -> {
            String name = nameField.getText();
            String phone = phoneField.getText();
            String card = cardField.getText();
            String exp = expField.getText();
            String cvv = cvvField.getText();
            
            // Validate fields
            if (name.isEmpty() || phone.isEmpty() || card.isEmpty() || exp.isEmpty() || cvv.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please fill in all fields.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            // Validate phone number
            if (!phone.matches("\\d{10}")) {
                JOptionPane.showMessageDialog(null, "Please enter a valid phone number.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            // Validate credit card number
            if (!card.matches("\\d{16}")) {
                JOptionPane.showMessageDialog(null, "Please enter a valid credit card number.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            // Validate expiry date
            if (!exp.matches("(0[1-9]|1[0-2])/\\d{2}")) {
                JOptionPane.showMessageDialog(null, "Please enter a valid expiry date (MM/YY).", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
// Validate CVV
if (!cvv.matches("\\d{3}")) {
    JOptionPane.showMessageDialog(null, "Please enter a valid CVV.", "Error", JOptionPane.ERROR_MESSAGE);
    return;
}


try {
    // Create a new PDF document
    Document document = new Document();
    PdfWriter.getInstance(document, new FileOutputStream("cab-invoice.pdf"));

    // Open the document
    document.open();

    // Add the heading
    Paragraph heading = new Paragraph("Cab Invoice");
    heading.setAlignment(Element.ALIGN_CENTER);
    document.add(heading);

    // Add the invoice date and time
    Date date = new Date();
    Paragraph invoiceDetails = new Paragraph("Invoice Date: " + date.toString());
    document.add(invoiceDetails);

    // Add the name and phone number
    Paragraph customerDetails = new Paragraph("Name: " + name + "\nPhone Number: " + phone);
    document.add(customerDetails);

    // Create a table to show trip details
    PdfPTable table = new PdfPTable(4);

    // Add the table headers
    PdfPCell cell1 = new PdfPCell(new Paragraph("From"));
    PdfPCell cell2 = new PdfPCell(new Paragraph("To"));
    PdfPCell cell3 = new PdfPCell(new Paragraph("Amount"));
    PdfPCell cell4 = new PdfPCell(new Paragraph("Date"));

    table.addCell(cell1);
    table.addCell(cell2);
    table.addCell(cell3);
    table.addCell(cell4);

    // Add the trip details
    table.addCell("Andheri");
    table.addCell("Virar");
    table.addCell("RS 500");
    LocalDate tripDate1 = LocalDate.of(2023, 4, 15);
    table.addCell(tripDate1.format(DateTimeFormatter.ofPattern("MM/dd/yyyy")));
    table.addCell("Mumbai");
    table.addCell("Goa");
    table.addCell("RS 2500");
    LocalDate tripDate2 = LocalDate.of(2023, 4, 20);
    table.addCell(tripDate2.format(DateTimeFormatter.ofPattern("MM/dd/yyyy")));
    table.addCell("Virar");
    table.addCell("Andheri");
    table.addCell("RS 15100");
    LocalDate tripDate3 = LocalDate.of(2023, 4, 25);
    table.addCell(tripDate3.format(DateTimeFormatter.ofPattern("MM/dd/yyyy")));

    // Add the table to the document
    document.add(table);

    // Add the total fare
    int totalFare = 500 + 2500 + 15100;
    Paragraph totalFarePara = new Paragraph("Total Fare: RS " + totalFare);
    document.add(totalFarePara);

    // Add the payment successful message
    Paragraph paymentSuccess = new Paragraph("Payment successful!");
    document.add(paymentSuccess);

    // Close the document
    document.close();

    // Show a success message
   JTextArea messageArea = new JTextArea(5, 20);
messageArea.append("Invoice generated successfully.\n");
messageArea.append("You can find the invoice at: " + new File("cab-invoice.pdf").getAbsolutePath());
JScrollPane scrollPane = new JScrollPane(messageArea);
JPanel messagePanel = new JPanel();
messagePanel.add(scrollPane);
JFrame messageFrame = new JFrame("Success");
messageFrame.getContentPane().add(BorderLayout.CENTER, messagePanel);
messageFrame.setSize(400, 200); // set the size of the frame to 400x200 pixels
messageFrame.setLocationRelativeTo(null); // center the frame on the screen
messageFrame.setVisible(true);


} catch (DocumentException | HeadlessException | FileNotFoundException ex) {
    // Show an error message
    JTextArea messageArea = new JTextArea(5, 20);
    messageArea.append("An error occurred while generating the invoice:\n" + ex.getMessage());
    JScrollPane scrollPane = new JScrollPane(messageArea);
    JPanel messagePanel = new JPanel();
    messagePanel.add(scrollPane);
    JFrame messageFrame = new JFrame("Error");
    messageFrame.getContentPane().add(BorderLayout.CENTER, messagePanel);
    messageFrame.pack();
    messageFrame.setVisible(true);
}
        });
    formPanel.add(generateButton);

    // Add the form panel to the frame
    frame.getContentPane().add(BorderLayout.CENTER, formPanel);

    // Display the frame
    frame.pack();
    frame.setSize(450, 210);
frame.setLocationRelativeTo(null);
frame.setVisible(true);
}

    void setVisible(boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}