package cab.booking.system;

import java.awt.*;
import java.awt.event.*;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.*;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;

public class CabInvoice extends JFrame implements ActionListener {
    private JLabel nameLabel, addressLabel, phoneLabel, dateLabel, fromLabel, toLabel, fareLabel, paymentLabel, ccLabel;
    private JTextField nameText, addressText, phoneText, dateText, fromText, toText, fareText, ccText;
    private JButton generateButton;
    private JRadioButton creditCardRadio, cashRadio;


    public CabInvoice() {
        super("Cab Invoice");
        setLayout(new GridLayout(9, 2));

        nameLabel = new JLabel("Passenger Name: ");
        add(nameLabel);
        nameText = new JTextField(20);
        add(nameText);

        addressLabel = new JLabel("Passenger Address: ");
        add(addressLabel);
        addressText = new JTextField(20);
        add(addressText);

        phoneLabel = new JLabel("Passenger Phone: ");
        add(phoneLabel);
        phoneText = new JTextField(20);
        add(phoneText);

        dateLabel = new JLabel("Date: ");
        add(dateLabel);
        dateText = new JTextField(getCurrentDate());
        add(dateText);

        fromLabel = new JLabel("From: ");
        add(fromLabel);
        fromText = new JTextField(20);
        add(fromText);

        toLabel = new JLabel("To: ");
        add(toLabel);
        toText = new JTextField(20);
        add(toText);

        fareLabel = new JLabel("Fare: ");
        add(fareLabel);
        fareText = new JTextField(20);
        add(fareText);

        paymentLabel = new JLabel("Payment Method: ");
        add(paymentLabel);
        creditCardRadio = new JRadioButton("Credit Card");
        add(creditCardRadio);
        cashRadio = new JRadioButton("Cash");
        add(cashRadio);
        ButtonGroup paymentGroup = new ButtonGroup();
        paymentGroup.add(creditCardRadio);
        paymentGroup.add(cashRadio);

        ccLabel = new JLabel("Credit Card Number: ");
        add(ccLabel);
        ccText = new JTextField(20);
        add(ccText);
        ccLabel.setVisible(false);
        ccText.setVisible(false);

        generateButton = new JButton("Generate Invoice");
        add(generateButton);
        generateButton.addActionListener(this);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 350);
        setVisible(true);

        creditCardRadio.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ccLabel.setVisible(true);
                ccText.setVisible(true);
            }
        });

        cashRadio.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ccLabel.setVisible(false);
                ccText.setVisible(false);
            }
        });
    }

    private String getCurrentDate() {
        Date currentDate = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        return formatter.format(currentDate);
    }

    private boolean isValidCCNumber(String ccNumber) {
        // TODO: Implement credit card number validation
        // For example, using regular expressions or a library like LuhnValidator
        return true;
    }

   public void actionPerformed(ActionEvent event) {
    if (event.getSource() == generateButton) {
        String passengerName = nameText.getText();
        String passengerAddress = addressText.getText();
        String passengerPhone = phoneText.getText();
        String date = dateText.getText();
        String from = fromText.getText();
        String to = toText.getText();
        String fare = fareText.getText ();
                String paymentMethod = "";
        if (creditCardRadio.isSelected()) {
            paymentMethod = "Credit Card";
        } else {
            paymentMethod = "Cash";
        }

        String ccNumber = "";
        if (paymentMethod.equals("Credit Card")) {
            ccNumber = JOptionPane.showInputDialog("Enter credit card number:");
            if (!isValidCCNumber(ccNumber)) {
                JOptionPane.showMessageDialog(null, "Invalid credit card number.");
                return;
            }
        }

        try {
            // Create PDF document
            Document document = new Document();
            PdfWriter.getInstance(document, new FileOutputStream("cab_invoice.pdf"));
            document.open();

            // Add content to PDF
            Paragraph heading = new Paragraph("Cab Invoice");
            heading.setAlignment(Element.ALIGN_CENTER);
            document.add(heading);

            document.add(new Paragraph("Passenger Name: " + passengerName));
            document.add(new Paragraph("Passenger Address: " + passengerAddress));
            document.add(new Paragraph("Passenger Phone: " + passengerPhone));
            document.add(new Paragraph("Date: " + date));
            document.add(new Paragraph("From: " + from));
            document.add(new Paragraph("To: " + to));
            document.add(new Paragraph("Fare: " + fare));

            if (paymentMethod.equals("Credit Card")) {
                if (isValidCCNumber(ccNumber)) {
                    document.add(new Paragraph("Payment Method: Credit Card"));
                    document.add(new Paragraph("Credit Card Number: " + ccNumber));
                    String ccExpiry = null;
                    document.add(new Paragraph("Credit Card Expiry: " + ccExpiry));
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid credit card number!");
                }
            } else {
                document.add(new Paragraph("Payment Method: Cash"));
            }

            // Close document
            document.close();

            JOptionPane.showMessageDialog(null, "Invoice generated successfully!");
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error generating invoice: " + e.getMessage());
        }
    }
}



public static void main(String[] args) {
        new CabInvoice();
    }
}
