import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

/**
 * Payment screen for a cab booking system.
 */
public class Payment extends JFrame{
    private JTextField nameField;
    private JTextField cardField;
    
    public Payment(){
        setLayout(null);
        setBounds(600, 220, 800, 600);
        
        JLabel label = new JLabel("Pay the payment");
        label.setFont(new Font("Raleway", Font.BOLD, 40));
        label.setBounds(50, 20, 350, 45);
        add(label);
        
        JLabel nameLabel = new JLabel("Name:");
        nameLabel.setBounds(50, 100, 80, 25);
        add(nameLabel);
        
        nameField = new JTextField();
        nameField.setBounds(140, 100, 200, 25);
        add(nameField);
        
        JLabel cardLabel = new JLabel("Card Number:");
        cardLabel.setBounds(50, 150, 80, 25);
        add(cardLabel);
        
        cardField = new JTextField();
        cardField.setBounds(140, 150, 200, 25);
        add(cardField);
        
        JLabel currencyLabel = new JLabel("Total Bill: $50.00");
        currencyLabel.setBounds(50, 200, 200, 25);
        add(currencyLabel);
        
        JLabel emailLabel = new JLabel("Email: example@example.com");
        emailLabel.setBounds(50, 250, 250, 25);
        add(emailLabel);
        
        JLabel paymentLabel = new JLabel("Payment Options:");
        paymentLabel.setBounds(50, 300, 150, 25);
        add(paymentLabel);
        
        JRadioButton creditCard = new JRadioButton("Credit Card");
        creditCard.setBounds(50, 330, 120, 25);
        creditCard.setSelected(true);
        add(creditCard);
        
        JRadioButton debitCard = new JRadioButton("Debit Card");
        debitCard.setBounds(170, 330, 100, 25);
        add(debitCard);
        
        JCheckBox cash = new JCheckBox("Cash");
        cash.setBounds(280, 330, 80, 25);
        add(cash);
        
        ButtonGroup group = new ButtonGroup();
        group.add(creditCard);
        group.add(debitCard);
        
        JButton payButton = new JButton("Pay");
        payButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
               String name = nameField.getText();
               String cardNumber = cardField.getText();
               if (name.isEmpty() || cardNumber.isEmpty()) {
                   JOptionPane.showMessageDialog(null, "Please enter name and card number.");
               } else if (cardNumber.length() != 16) {
                   JOptionPane.showMessageDialog(null, "Card number should be 16 digits.");
               } else {
                   // Process payment here
                   JOptionPane.showMessageDialog(null, "Paid successfully");
               }
            }
        });
        payButton.setBounds(420, 20, 80, 40);
        add(payButton);
    
        JButton backButton = new JButton("Back");
        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
            }
        });
        backButton.setBounds(510, 20, 80, 40);
        add(backButton);
        
        getContentPane().setBackground(Color.WHITE);
        setVisible(true);

    }

    public static void main(String[] args){
        new Payment().setVisible(true);
    }
    
}
