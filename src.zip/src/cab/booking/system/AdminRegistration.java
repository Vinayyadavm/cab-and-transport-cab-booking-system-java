package cab.booking.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.regex.*;

public class AdminRegistration extends JFrame {

    public AdminRegistration() {
    // Set up the JFrame
    super("Admin Registration");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setSize(300, 200);
    setLocationRelativeTo(null);

    // Create the UI components
    JLabel label = new JLabel("Admin Registration Form");
    JLabel nameLabel = new JLabel("Name:");
    JLabel emailLabel = new JLabel("Email:");
    JLabel passwordLabel = new JLabel("Password:");
    JTextField nameTextField = new JTextField();
    JTextField emailTextField = new JTextField();
    JPasswordField passwordField = new JPasswordField();
    JButton registerButton = new JButton("Register");
    JButton backButton = new JButton("Back");

    // Add the components to the JFrame
    Container contentPane = getContentPane();
    contentPane.setLayout(new GridLayout(5, 2));
    contentPane.add(nameLabel);
    contentPane.add(nameTextField);
    contentPane.add(emailLabel);
    contentPane.add(emailTextField);
    contentPane.add(passwordLabel);
    contentPane.add(passwordField);
    contentPane.add(new JLabel(""));
    contentPane.add(registerButton);
    contentPane.add(backButton);

    // Add event listener to the register button
    registerButton.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            // Get the user inputs
            String name = nameTextField.getText();
            String email = emailTextField.getText();
            String password = new String(passwordField.getPassword());

            // Validate the email
            Pattern pattern = Pattern.compile("^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$");
            Matcher matcher = pattern.matcher(email);
            boolean isEmailValid = matcher.matches();

            if (name.isEmpty() || email.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(AdminRegistration.this, "Please fill all the fields.");
            } else if (!isEmailValid) {
                JOptionPane.showMessageDialog(AdminRegistration.this, "Please enter a valid email address.");
            } else {
                // TODO: Implement registration logic
                // Once registration is successful, redirect to the login page
                JOptionPane.showMessageDialog(AdminRegistration.this, "Admin registration successful.");
                LoginPage loginPage = new LoginPage();
                loginPage.setVisible(true);
                dispose();
            }
        }
    });

    // Add event listener to the back button
    backButton.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            // Go back to the previous page
            // In this example, assume the previous page is the main menu
            LoginPage LoginPage = new LoginPage();
            LoginPage.setVisible(true);
            dispose();
        }
    });
}

public static void main(String[] args) {
    // Create and show the admin registration page
    AdminRegistration adminRegistrationPage = new AdminRegistration();
    adminRegistrationPage.setVisible(true);
}
}