package cab.booking.system;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Random;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import com.itextpdf.text.Document;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

public class PaymentForm extends JFrame {
    private JLabel nameLabel;
    private JTextField nameField;
    private JLabel cardLabel;
    private JTextField cardField;
    private JLabel emailLabel;
    private JTextField emailField;
    private JLabel amountLabel;
    private JTextField amountField;
    private JLabel currencyLabel;
    private JComboBox<String> currencyBox;
    private JButton payButton;
    private JButton receiptButton;

    public PaymentForm() {
        setBounds(800, 420, 950, 750);
        JPanel contentPane = new JPanel();
        setContentPane(contentPane);
        contentPane.setLayout(null);
        initComponents();
    }

    PaymentForm(double fare) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void initComponents() {
        nameLabel = new JLabel("Name:");
        nameField = new JTextField();
        cardLabel = new JLabel("Card Number:");
        cardField = new JTextField();
        emailLabel = new JLabel("Email:");
        emailField = new JTextField();
        amountLabel = new JLabel("Amount:");
        amountField = new JTextField();
        currencyLabel = new JLabel("Currency:");
        currencyBox = new JComboBox<>(new String[]{"INR", "EUR", "USD"});
        payButton = new JButton("Pay Now");

        // set layout
        GroupLayout layout = new GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                        .addComponent(nameLabel)
                                        .addComponent(cardLabel)
                                        .addComponent(emailLabel)
                                        .addComponent(amountLabel)
                                        .addComponent(currencyLabel))
                                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                        .addComponent(nameField)
                                        .addComponent(cardField)
                                        .addComponent(emailField)
                                        .addComponent(amountField)
                                        .addComponent(currencyBox, 0, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addContainerGap())
                        .addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addContainerGap(150, Short.MAX_VALUE)
                                .addComponent(payButton)
                                .addGap(147, 147, 147))
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                        .addComponent(nameLabel)
                                        .addComponent(nameField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                        .addComponent(cardLabel)
                                        .addComponent(cardField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                        .addComponent(emailLabel)
                                        .addComponent(emailField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                        .addComponent(amountLabel)
                                        .addComponent(amountField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                        .addComponent(currencyLabel)
                                        .addComponent(currencyBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 18, Short.MAX_VALUE)
                                .addComponent(payButton)
                                .addContainerGap())
        );

        pack();

        // add action listener to pay button
        payButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // get input values
                String name = nameField.getText();
                String cardNumber = cardField.getText();
                String email = emailField.getText();
String amount = amountField.getText();
String currency = (String) currencyBox.getSelectedItem();
            // check if any field is empty
            if (name.isEmpty() || cardNumber.isEmpty() || email.isEmpty() || amount.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please fill all the fields.");
                return;
            }
            
            // check if amount is valid
            try {
                Double.parseDouble(amount);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Please enter a valid amount.");
                return;
            }
            
            // check if email is valid
            if (!email.matches("[\\w-]+@([\\w-]+\\.)+[\\w-]+")) {
                JOptionPane.showMessageDialog(null, "Please enter a valid email address.");
                return;
            }
            
            // validate card number
if (!cardNumber.matches("\\d{16}")) {
    JOptionPane.showMessageDialog(null, "Please enter a valid 16-digit card number.");
    return;
}


            
            // generate random payment id
            String paymentId = generatePaymentId();
            
          

            
            // payment logic here
            double amountNum = Double.parseDouble(amount);
            String message = "Payment Successful! Details:\n\n" +
                             "Payment ID: " + paymentId + "\n" +
                             "Name: " + name + "\n" +
                             "Card Number: " + cardNumber + "\n" +
                             "Amount: " + amount + " " + currency + "\n" +
                             "Email: " + email;
            JOptionPane.showMessageDialog(null, message);
        }
    });
}

private String generatePaymentId() {
    String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    StringBuilder builder = new StringBuilder();
    Random rnd = new Random();
    while (builder.length() < 10) {
        int index = (int) (rnd.nextFloat() * chars.length());
        builder.append(chars.charAt(index));
    }
    return builder.toString();
}


public static void main(String[] args) {
    PaymentForm paymentForm = new PaymentForm();
    paymentForm.setVisible(true);
}
}
