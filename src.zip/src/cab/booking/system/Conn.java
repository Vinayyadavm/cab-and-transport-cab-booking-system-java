
package cab.booking.system;


import java.sql.*;  

public class Conn{
    Connection c;
    Statement s;
    public Conn(){  
        try{  
            Class.forName("com.mysql.jdbc.Driver");  
            c =DriverManager.getConnection("jdbc:mysql://localhost:3306/cabdb1","root","1234567890"); 
            
            s =c.createStatement();  
            
            if (c.isClosed())
            {
                boolean yes = false;
                System.out.println("yes");
            }
            else
            {
                 System.out.println("No");
            }
            
           
        }catch(ClassNotFoundException | SQLException e)
        {
            e.printStackTrace();
        }  
    } 
    public static void main(String args[])
    {
        Conn conn = new Conn();
    }        
}  


